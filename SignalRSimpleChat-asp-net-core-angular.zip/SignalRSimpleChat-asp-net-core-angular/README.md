# Requirements
1. [Angular CLI](https://github.com/angular/angular-cli)
2. [.NET Core SDK](https://www.microsoft.com/net/download)

# How to run the application
1. Navigate inside of **AngularAspNetCoreSignalR.Angular** folder and enter _**npm install**_
2. Start the client app by entering _**ng serve**_
3. Navigate inside of **AngularAspNetCoreSignalR** and enter **_dotnet run_** to start the server app (the packages will be restored automatically)
 